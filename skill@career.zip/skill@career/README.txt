Skill2Career - Gemini CareerBot patch

1. Back up your existing project folder.
2. Replace your existing app.py with this app.py.
3. Keep your existing templates/static files and MySQL database. This ZIP does not replace them.
4. Create/update .env beside app.py using .env.example.
5. Put your NEW Gemini key in GEMINI_API_KEY. Do not use OPENAI_API_KEY for Gemini.
6. Install dependencies:
   py -m pip install -r requirements.txt
7. Stop the old Flask server (Ctrl+C), then start:
   py app.py
8. Log in and test CareerBot.

Security:
- Revoke the Gemini key that was included in the uploaded .env file and create a replacement.
- Never upload .env or commit it to GitHub.
- This code calls Gemini's generateContent API from Flask; the key is not sent to browser JavaScript.

The rest of the uploaded app.py routes and website features are preserved.
